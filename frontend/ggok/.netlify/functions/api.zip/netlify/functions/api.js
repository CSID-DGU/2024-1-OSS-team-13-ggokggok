const fetch = require('node-fetch');

exports.handler = async function(event, context) {
  // '/.netlify/functions/api' 부분을 제거하고 실제 API 경로를 사용
  const path = event.path.replace('/v1', '');
  const url = `https://openapi.naver.com${path}`;  // 실제 Naver API 경로

  try {
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        'X-Naver-Client-Id': 'WDVId7gO_fHzG7oRtf5w',
        'X-Naver-Client-Secret': 'q4MDc81Fjb',
      }
    });

    if (!response.ok) {
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: 'Failed to fetch data from Naver API' }),
      };
    }

    const data = await response.json();
    return {
      statusCode: 200,
      body: JSON.stringify(data),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to fetch data from Naver API' }),
    };
  }
};
